package com.Tubes.VapeConnects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VapeConnectsApplicationTests {

	@Test
	void contextLoads() {
	}

}
