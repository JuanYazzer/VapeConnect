// package com.Tubes.VapeConnects.model;

// public class Customer extends User{
//     private Cart cart;

//     public Customer(int id, String username, String email, String password) {
//         super(id, username, email, password);
//         this.cart = new Cart();
//     }
//     public Cart getCart() {
//         return cart;
//     }
// }
